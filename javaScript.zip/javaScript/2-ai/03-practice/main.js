// class Pr {
//     a = ""
//     b = ""
//     constructor(a, b) {
//         this.a = a
//         this.b = b
//     }

//     perimetr = () => {
//         console.log((this.a + this.b) * 2)
//     }

//     ploshat = () => {
//         console.log(this.a * this.b);
//     }
// }

// const pr1 = new Pr(3,8)
// pr1.perimetr()
// pr1.ploshat()


class Metr {

}

const metr1 = new Metr(20)
metr1.km()
metr1.cm()


