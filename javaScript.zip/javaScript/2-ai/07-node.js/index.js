// console.log("hello world")
//  const arr=[1,2,3,4,5,6,5,4,3,2,1]
//   for (let i=0; i<arr["length"]; i++){
//       console.log(arr[i])


//   +1 koshu uchun
//     let summa=0
//     const arr=[1,2,3,4,5,6,5,4,3,2,1]
//     for (let i=0; i<arr["length"]; i++){
//         summa+=arr[i]}
//         console.log(summa)

// enkichine summanu tabuu

// const arr = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
// let minNam = arr[0]
// for (let i = 0; i < arr.length; i++) {
//     if (arr[i] < minNam) {
//         minNam = arr[i]
//     }
// // }
// enchonun taduu
// const arr = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
// let minNam = arr[0]
// for (let i = 0; i < arr.length; i++) {
//     if (arr[i] > minNam) {
//         minNam = arr[i]
//     }
// }
// console.log(minNam)



// const arr = [1, 2, 3, 4, 5, 6, 5, 4, 3, 2, 1]
// for (let i = 0; i < arr.length; i++) {
//     if (arr[i]%2===0) {
//         console.log=( arr[i])
//     }
// }
// jupsan bolunup chuccan san

const arr=[1,3,5,7,9]
for (let i = 0; i < arr.length; i+=2) {
        console.log(arr[i])
    }
// 2-sandu rorsotot




