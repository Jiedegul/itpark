// const numbers = [4, 3, 5, 6, 2,7,3,7,4]

// let summa = 0
// for (let i = 0; i < numbers["length"]; i++) {
//     summa += numbers[i]
// }

// console.log(summa)

// for (let i=0;i < numbers["length"];i++){
//     if (numbers[i]%2 == 0){
//         console.log(numbers[i])
//     }
// }



// for (let i = 0;i<100;i++){
//     if (i**2 === 7569){
//         console.log(i)
//     }
// }


// for (let i = 0; i < numbers["length"];i++) {
//     if(numbers[i]<5){
//         console.log(numbers[i])
//     }
// }


// const users = [
//     { username: "asan", password: "123", age: 17 },
//     { username: "hasan", password: "1234", age: 18 },
//     { username: "tasan", password: "12345", age: 19 },
// ]

// const username = prompt("Username")
// const password = prompt("Password")

// for (let i = 0; i < users["length"]; i++) {
//     const user = users[i]
//     if (user.username === username && user.password === password ) {
//         console.log("Login")
//     }
// }

// for (let i = 0; i < users["length"]; i++) {
//     const user = users[i]
//     if (user.age >= 18){
//         console.log(user.username)
//     }
// }


