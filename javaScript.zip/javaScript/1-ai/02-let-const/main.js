// let age = 18
// let username = "Nurkadyr"
// console.log(username,age)
// age = 26
// username = "Asan"
// console.log(username,age)

// const age = 18
// const username = "Nurkadyr"
// console.log(username,age)

