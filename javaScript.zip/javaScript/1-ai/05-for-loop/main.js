// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")
// document.write("Nurkadyr<br>")

// const tbody = document.querySelector("tbody")

// for (let i = 1; i <= 10; i++) {
//     tbody.innerHTML += "<tr><td>"+i+"</td><td>"+i**2+"</td></tr>"
// }



// const ol = document.querySelector('ol')

// for (let i = 0; i<=10;i++){
//     ol.innerHTML += "<li>" + 2**i+"</li>"
// }


// const tbody = document.querySelector("tbody")

// for( let i = 1; i<=10;i++){
//     let tr = "<tr>"
//     for(let e = 1; e<=10; e++){
//         tr += "<td>"+i*e+"</td>"
//     }
//     tbody.innerHTML += tr + "</tr>"
// }

// const section = document.querySelector("section")

// for( let i = 1; i<=97;i++){
//     setTimeout(()=>{
//         section.innerHTML+="<div class='box'></div>"
//     },i*100)
// }