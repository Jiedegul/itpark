// const point = 84

// if (point >= 85){
//     console.log(5)
// } 


// const bread = 30
// const money = 25


// if (bread <= money) {
//     console.log("сатып алат")
// }

// if (bread > money){
//     console.log("сатып албайт")
// }


// const point = 55

// if (point>=40){
//     console.log("Отту")
// } else {
//     console.log("Отподу")
// }


// const point = 55

// if (point >= 85){
//     console.log(5)
// } else if (point >= 60){
//     console.log(4)
// } else if (point >= 40){
//     console.log(3)
// } else {
//     console.log(2)
// }

// const age = 18



// const nBread = 100;
// const sBread = 100;
// const breadPrice = 20
// const money = 2000

// if (nBread <= sBread && nBread*breadPrice <= money){
//     console.log("buy breads")
// } else {
//     console.log("no breads")
// }




