window.onscroll = () => {
    console.log("hello world")
}